import type { VercelRequest, VercelResponse } from '@vercel/node';
import crypto from 'crypto';
import { parseCookies, verifySessionToken } from './_helpers.js';

function safeJson(value: unknown) {
  return JSON.stringify(value, null, 2)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026');
}

function hash(value: string): string {
  let h = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(36);
}

const LEGACY_DATA_URLS: Record<string, string> = {
  '29cbdd45ce9db2074533ba5b587be27fd2eafe2e3e441cb8bc35d8b3f6c41259': '/assets/persistent-media-1.png',
  '4e6d3b32587362a2efa8b5dccdc177b9cc553c0e60bff5d0cbc6246b513ddded': '/assets/persistent-media-2.png',
};

function sanitizePersistedMedia(value: unknown): any {
  if (typeof value === 'string') {
    if (!value.startsWith('data:image/')) return value;
    // SHA-256 évite de conserver la moindre image inline dans le fichier
    // généré. Les deux anciennes images connues sont conservées localement.
    const hashValue = crypto.createHash('sha256').update(value).digest('hex');
    return LEGACY_DATA_URLS[hashValue] || '';
  }
  if (Array.isArray(value)) return value.map(sanitizePersistedMedia);
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([key, child]) => [key, sanitizePersistedMedia(child)])
    );
  }
  return value;
}

/**
 * Nettoyage V4 du snapshot visuel.
 *
 * IMPORTANT :
 * brandData reste la donnée métier/canonique.
 * Les modifications faites avec l'éditeur visuel restent dans editorConfig.
 * On ne remplace donc PAS :
 *
 *   brandData.tagline = "element-123"
 *
 * car cela casserait les composants React qui attendent une vraie chaîne.
 *
 * Le lien canonique est :
 *
 *   editorConfig.blocks[].id
 *          ↓
 *   editorElements[id]
 *          ↓
 *   locator DOM stable
 *
 * Le selector est conservé uniquement pour les anciennes publications et
 * pour retrouver un élément lors du premier rendu après un refresh.
 */
function normalizeEditorConfig(input: any) {
  const source = input && typeof input === 'object' ? input : {};
  const rawBlocks = Array.isArray(source.blocks) ? source.blocks : [];

  const byId = new Map<string, any>();
  const bySelector = new Map<string, string>();

  for (let index = 0; index < rawBlocks.length; index += 1) {
    const raw = rawBlocks[index];
    if (!raw || typeof raw !== 'object') continue;

    const selector =
      typeof raw.selector === 'string' ? raw.selector.trim() : '';

    // Un bloc sans selector, sans binding et sans contenu exploitable ne peut
    // rien appliquer au DOM : on le retire du snapshot pour éviter les vieux
    // blocs fantômes accumulés au fil des versions.
    const hasContent =
      typeof raw.text === 'string' ||
      typeof raw.url === 'string' ||
      typeof raw.link === 'string' ||
      typeof raw.fontFamily === 'string' ||
      typeof raw.fontSize === 'string' ||
      typeof raw.color === 'string';

    if (!selector && !hasContent) continue;

    const type = typeof raw.type === 'string' ? raw.type : 'text';
    const section =
      typeof raw.section === 'string' ? raw.section : 'hero';

    const kind =
      raw.kind === 'media' || raw.kind === 'text'
        ? raw.kind
        : type === 'image' || type === 'video'
          ? 'media'
          : 'text';

    // Les anciens IDs `element-<timestamp>` étaient recréés à chaque édition.
    // Ils donnent l'impression qu'un même élément est plusieurs éléments
    // différents et rendent les snapshots historiques difficiles à fusionner.
    // Un locator visuel est déterministe : même section + type + kind +
    // selector = même identité. Les IDs explicitement nommés par une future
    // version de l'éditeur restent conservés.
    const rawId = typeof raw.id === 'string' ? raw.id.trim() : '';
    const generatedId = !rawId || /^(?:element|text|media)-\d+$/.test(rawId);
    const id = generatedId
      ? `element-${hash(`${section}|${type}|${kind}|${selector || 'no-selector'}`)}`
      : rawId;

    const cleanedBlock = {
      ...raw,
      id,
      type,
      section,
      kind,
      selector: selector || undefined,
      visible: raw.visible !== false,
    };

    // Dernière modification = priorité.
    byId.set(id, cleanedBlock);

    // Si plusieurs blocs ciblent exactement le même selector, seul le dernier
    // reste actif. Cela élimine une grande partie des doublons historiques.
    if (selector) {
      bySelector.set(selector, id);
    }
  }

  const blocks = Array.from(byId.values()).filter((block) => {
    if (!block.selector) return true;
    return bySelector.get(block.selector) === block.id;
  });

  const editorElements: Record<string, unknown> = {};

  for (const block of blocks) {
    editorElements[block.id] = {
      id: block.id,
      type: block.type,
      kind: block.kind,
      section: block.section,
      selector: block.selector || null,
      locator: 'data-vce-id',
    };
  }

  return {
    // On conserve les options de l'éditeur existantes.
    ...Object.fromEntries(
      Object.entries(source).filter(
        ([key]) =>
          key !== 'blocks' &&
          key !== 'editorElements' &&
          key !== 'schemaVersion'
      )
    ),

    schemaVersion: 5,
    blocks,
    editorElements,
  };
}

function generatedFile(config: any) {
  const cleanConfig = sanitizePersistedMedia(config);
  const brandData = cleanConfig?.brandData ?? {};
  const editorConfig = normalizeEditorConfig(cleanConfig?.editorConfig);
  const publishedAt = Number(config?.publishedAt) || Date.now();

  return `// AUTO-GENERATED BY THE SITE VISUAL EDITOR.
// Do not edit manually: the next publication will overwrite this file.

export const publishedSiteContent = ${safeJson({
    brandData,
    editorConfig,
    publishedAt,
  })} as const;
`;
}

export default async function handler(
  req: VercelRequest,
  res: VercelResponse
) {
  if (req.method !== 'PUT') {
    return res
      .status(405)
      .json({ success: false, error: 'Method not allowed' });
  }

  const session = verifySessionToken(
    parseCookies(req.headers.cookie).admin_session
  );

  if (!session.valid) {
    return res
      .status(401)
      .json({ success: false, error: 'Non autorisé' });
  }

  const token = process.env.GITHUB_TOKEN;
  const repository = process.env.GITHUB_REPOSITORY;
  const branch = process.env.GITHUB_BRANCH || 'main';
  const filePath =
    process.env.GITHUB_PUBLISHED_FILE ||
    'src/data/site-content.generated.ts';

  if (!token || !repository) {
    return res.status(503).json({
      success: false,
      error: 'GITHUB_TOKEN ou GITHUB_REPOSITORY manque dans Vercel.',
    });
  }

  const body =
    typeof req.body === 'string' ? JSON.parse(req.body) : req.body;

  const config = body?.config;

  if (!config || typeof config !== 'object') {
    return res.status(400).json({
      success: false,
      error: 'config est obligatoire.',
    });
  }

  const [owner, repo] = repository.split('/');

  if (!owner || !repo) {
    return res.status(500).json({
      success: false,
      error: 'GITHUB_REPOSITORY doit être owner/repository.',
    });
  }

  const apiUrl =
    `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`;

  const headers = {
    Accept: 'application/vnd.github+json',
    Authorization: `Bearer ${token}`,
    'X-GitHub-Api-Version': '2022-11-28',
    'Content-Type': 'application/json',
    'User-Agent': 'Site-Internet-Benoit-V5',
  };

  try {
    const content = generatedFile(config);
    const encoded = Buffer.from(content, 'utf8').toString('base64');

    const readCurrent = async () => {
      const existing = await fetch(
        `${apiUrl}?ref=${encodeURIComponent(branch)}`,
        { headers }
      );

      if (existing.ok) return await existing.json();

      if (existing.status === 404) return null;

      const text = await existing.text();

      throw new Error(
        `Lecture GitHub impossible (${existing.status}): ${text.slice(
          0,
          300
        )}`
      );
    };

    const updateOnce = async (sha?: string) => {
      const payload: Record<string, unknown> = {
        message:
          'chore(site-editor): normalize published visual snapshot v5',
        content: encoded,
        branch,
      };

      if (sha) payload.sha = sha;

      return fetch(apiUrl, {
        method: 'PUT',
        headers,
        body: JSON.stringify(payload),
      });
    };

    let existingData = await readCurrent();

    // Aucun commit si le fichier généré est déjà strictement identique.
    if (existingData?.content) {
      try {
        const currentContent = Buffer.from(
          String(existingData.content).replace(/\s+/g, ''),
          'base64'
        ).toString('utf8');

        if (currentContent === content) {
          return res.status(200).json({
            success: true,
            commitSha: null,
            unchanged: true,
            path: filePath,
            branch,
          });
        }
      } catch {
        // Continuer normalement.
      }
    }

    let update = await updateOnce(existingData?.sha);

    // Protection contre une publication concurrente.
    if (update.status === 409) {
      existingData = await readCurrent();
      update = await updateOnce(existingData?.sha);
    }

    const result = await update.json().catch(() => ({}));

    if (!update.ok) {
      return res.status(502).json({
        success: false,
        error:
          result?.message ||
          `GitHub a refusé la publication (${update.status}).`,
      });
    }

    return res.status(200).json({
      success: true,
      commitSha: result?.commit?.sha || null,
      path: filePath,
      branch,
    });
  } catch (error) {
    console.error('site-publish:', error);

    return res.status(500).json({
      success: false,
      error: 'Erreur pendant la publication GitHub.',
    });
  }
}
